<!-- Elyass Jerari -->
<?php
    define("HOST", "localhost");
    define("USER", "root");
    define("PASS", "");
    define("DB", "pt02_elyass_jerari");
?>